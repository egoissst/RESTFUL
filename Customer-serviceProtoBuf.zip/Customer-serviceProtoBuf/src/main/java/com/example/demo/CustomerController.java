package com.example.demo;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.services.protobuf.customer.model.CustomerProto.Accounts;
import com.example.services.protobuf.customer.model.CustomerProto.Customer;
import com.example.services.protobuf.customer.model.CustomerProto.Customers;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerRepository repository;
	
	
	protected Logger logger = Logger.getLogger(CustomerController.class.getName());
	
	@Autowired
	AccountClient accountClient;
	
	@RequestMapping(value = "/customers", produces = "application/x-protobuf")
	public Customers findAll() {
		logger.info("Customer.findAll()");
		return Customers.newBuilder().addAllCustomers(repository.findAll()).build();
	}
	
	@RequestMapping(value = "/customers/{id}", produces = "application/x-protobuf")
	public Customer findById(@PathVariable("id") Integer id) {
		logger.info(String.format("Customer.findById(%s)", id));
		Customer customer = repository.findById(id);
		Accounts accounts =  accountClient.getAccounts(id);		
		customer = Customer.newBuilder(customer).addAllAccounts(accounts.getAccountList()).build();
		return customer;
	}
	
}