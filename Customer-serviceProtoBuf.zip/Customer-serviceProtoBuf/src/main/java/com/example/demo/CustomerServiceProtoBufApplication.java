package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.protobuf.ProtobufHttpMessageConverter;

import com.example.services.protobuf.customer.model.CustomerProto.Customer;
import com.example.services.protobuf.customer.model.CustomerProto.Customer.CustomerType;

@SpringBootApplication
@EnableFeignClients
public class CustomerServiceProtoBufApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerServiceProtoBufApplication.class, args);
	}

	@Bean
	ProtobufHttpMessageConverter protobufHttpMessageConverter() {
		return new ProtobufHttpMessageConverter();
	}
	
	@Bean
	CustomerRepository repository() {
		List<Customer> customers = new ArrayList<>();
		customers.add(Customer.newBuilder().setId(1).setName("Rahul Prakash")
				.setType(CustomerType.INDIVIDUAL).build());
		customers.add(Customer.newBuilder().setId(2).setName("Angelina Jolie")
				.setType(CustomerType.INDIVIDUAL).build());
		customers.add(Customer.newBuilder().setId(3).setName("Ashok Kumar")
				.setType(CustomerType.COMPANY).build());
		customers.add(Customer.newBuilder().setId(4).setName("Asha Bhat")
				.setType(CustomerType.INDIVIDUAL).build());
		return new CustomerRepository(customers);
	}

}
