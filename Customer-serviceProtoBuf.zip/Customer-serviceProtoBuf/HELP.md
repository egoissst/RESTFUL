https://github.com/protocolbuffers/protobuf/releases

protoc --java_out=./src/main/java/ -I=./src/main/resources/ customer.proto
