package com.adobe;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@ExtendWith(SpringExtension.class)
@WebFluxTest
public class FluxControllerTest {
	@Autowired
	WebTestClient webTestClient;
	

	@Test
	public void fluxApproach() {
		 webTestClient.get().uri("/hello")
//			.accept(MediaType.APPLICATION_JSON_UTF8)
			.exchange()
			.expectStatus().isOk()
			.expectBodyList(Integer.class)
			.hasSize(4);
	}
	

	@Test
	public void fluxApproachResultData() {
		List<Integer> expected = Arrays.asList(10,20,30,40);
		
		EntityExchangeResult<List<Integer>> res =   webTestClient.get().uri("/hello")
		  .accept(MediaType.APPLICATION_JSON_UTF8)
			.exchange()
			.expectStatus().isOk()
			.expectBodyList(Integer.class)
			.returnResult();
		
				assertEquals(expected, res.getResponseBody());
				
		System.out.println("************ OR ************");
		
		webTestClient.get().uri("/hello")
		  .accept(MediaType.APPLICATION_JSON_UTF8)
			.exchange()
			.expectStatus().isOk()
			.expectBodyList(Integer.class)
			.consumeWith(resp -> {
				assertEquals(expected, resp.getResponseBody());
			});
		
				
		
	}
	
	@Test
	public void fluxApproachStream() {
		Flux<Integer> flux = webTestClient.get().uri("/hello/stream")
//			.accept(MediaType.APPLICATION_JSON_UTF8)
			.exchange()
			.expectStatus().isOk()
			.returnResult(Integer.class)
			.getResponseBody();
		
		StepVerifier.create(flux)
			.expectSubscription()
			.expectNext(10)
			.expectNext(20)
			.thenCancel()
			.verify();
//			.verifyComplete();
	}
	
	@Test
	public void monoTest() {
		webTestClient.get().uri("/hello/mono")
		  .accept(MediaType.APPLICATION_JSON_UTF8)
			.exchange()
			.expectStatus().isOk()
			.expectBody(String.class)
			.consumeWith(resp -> {
				assertEquals("Hello World", resp.getResponseBody());
			});
		
	}
}

