package com.adobe;

import org.junit.jupiter.api.Test;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class FluxAndMonoTest {

	@Test
	public void fluxTest() {
		Flux<String> flux = 
				Flux.just("spring", "jpa", "Hibernate", "Reactor","RxJava");
				flux.subscribe(System.out::println);
				
	}
	
	@Test
	public void fluxTestAssert() {
		Flux<String> flux = 
				Flux.just("spring", "jpa");
		StepVerifier.create(flux).expectNext("spring").expectNext("jpa").verifyComplete();
		
		StepVerifier.create(flux).expectNextCount(2).verifyComplete();
				
	}
	
	@Test
	public void fluxTestAssertError() {
		Flux<String> flux = 
				Flux.just("spring", "jpa")
				.concatWith(Flux.error(new RuntimeException("Boom :-("))).log();
		
		StepVerifier.create(flux)
			.expectNext("spring")
			.expectNext("jpa")
			.expectErrorMessage("Boom :-(")
			.verify();
				
	}
	
	@Test
	public void monoTest() {
		Mono<String> mono = Mono.just("spring");
		StepVerifier.create(mono).expectNext("spring").verifyComplete();
	}
	
	
	
}
