package com.adobe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactivespringApplicationTests {

	@Test
	void contextLoads() {
	}

}
