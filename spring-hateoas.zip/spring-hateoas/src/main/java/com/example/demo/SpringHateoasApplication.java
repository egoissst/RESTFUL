package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.hateoas.config.EnableHypermediaSupport;
import org.springframework.hateoas.config.EnableHypermediaSupport.HypermediaType;

@SpringBootApplication
//@EnableHypermediaSupport(type=HypermediaType.HAL_FORMS)
public class SpringHateoasApplication implements CommandLineRunner {
	
	@Autowired
	OrderRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringHateoasApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
			repository.save(new Order("Red Velvet"));
			repository.save(new Order("Mocha"));
	}

}
