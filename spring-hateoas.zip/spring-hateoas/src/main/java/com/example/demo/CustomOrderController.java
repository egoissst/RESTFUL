package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class CustomOrderController {
	
	@Autowired
	private   OrderRepository repository;
	
	@Autowired
	private OrderProcessor orderProcessor;
	
	@GetMapping("/orders")
	public @ResponseBody Iterable<Order> getOrders() {
		return repository.findAll();
	}
	
	@GetMapping("/orders/{id}")
	ResponseEntity<?> getOrder(@PathVariable("id") Long id) {
		Order order = this.repository.findById(id).orElseThrow(() -> new OrderNotFoundException(id));
		return ResponseEntity.ok(orderProcessor.process(EntityModel.of(order)));
	}
	
	@PostMapping("/orders/{id}/pay")
	ResponseEntity<?> pay(@PathVariable("id") Long id) {

		Order order = this.repository.findById(id).orElseThrow(() -> new OrderNotFoundException(id));

		if (OrderStatus.valid(order.getOrderStatus(), OrderStatus.PAID_FOR)) {

			order.setOrderStatus(OrderStatus.PAID_FOR);
			return ResponseEntity.ok(repository.save(order));
		}

		return ResponseEntity.badRequest()
				.body("Transitioning from " + order.getOrderStatus() + " to " + OrderStatus.PAID_FOR + " is not valid.");
	}

	@PostMapping("/orders/{id}/cancel")
	ResponseEntity<?> cancel(@PathVariable("id") Long id) {

		Order order = this.repository.findById(id).orElseThrow(() -> new OrderNotFoundException(id));

		if (OrderStatus.valid(order.getOrderStatus(), OrderStatus.CANCELLED)) {

			order.setOrderStatus(OrderStatus.CANCELLED);
			return ResponseEntity.ok(repository.save(order));
		}

		return ResponseEntity.badRequest()
				.body("Transitioning from " + order.getOrderStatus() + " to " + OrderStatus.CANCELLED + " is not valid.");
	}

	@PostMapping("/orders/{id}/fulfill")
	ResponseEntity<?> fulfill(@PathVariable("id") Long id) {

		Order order = this.repository.findById(id).orElseThrow(() -> new OrderNotFoundException(id));

		if (OrderStatus.valid(order.getOrderStatus(), OrderStatus.FULFILLED)) {

			order.setOrderStatus(OrderStatus.FULFILLED);
			return ResponseEntity.ok(repository.save(order));
		}

		return ResponseEntity.badRequest()
				.body("Transitioning from " + order.getOrderStatus() + " to " + OrderStatus.FULFILLED + " is not valid.");
	}
}
