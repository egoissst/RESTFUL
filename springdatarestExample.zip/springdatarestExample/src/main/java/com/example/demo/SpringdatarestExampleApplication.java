package com.example.demo;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringdatarestExampleApplication implements CommandLineRunner {

	@Autowired
	CompanyRepository companyRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringdatarestExampleApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Product iphone12 = new Product("iPhone 12");
		Product iPadPro = new Product("iPadPro");

		Set<Product> appleProducts = Stream.of(iphone12, iPadPro).collect(Collectors.toSet());

		Company apple = new Company("Apple", appleProducts);

		iphone12.setCompany(apple);
		iPadPro.setCompany(apple);

		companyRepository.save(apple);

		Product photoshop = new Product("Photoshop");
		Product afterEffects = new Product("After Effects");
		Product illustrator = new Product("Illustrator");

		Set<Product> adobeProducts = Stream.of(photoshop, afterEffects, illustrator).collect(Collectors.toSet());

		Company adobe = new Company("Adobe", adobeProducts);

		photoshop.setCompany(adobe);
		afterEffects.setCompany(adobe);
		illustrator.setCompany(adobe);

		companyRepository.save(adobe);
	}
}
